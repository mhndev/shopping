<?php
return array(
'el_finder_path'=>'elfinder'
);

?>