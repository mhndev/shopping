<?php

class Test extends Magniloquent {
	protected $fillable = [];
	public $table = 'tests';
}