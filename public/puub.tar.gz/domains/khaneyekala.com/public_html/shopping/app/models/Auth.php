<?php


class Auth extends Eloquent{
	
	protected $table = 'auth';

}
