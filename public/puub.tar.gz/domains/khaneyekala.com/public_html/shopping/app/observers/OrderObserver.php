<?php
use Illuminate\Events\Dispatcher;
class OrderObserver
{
    protected $events;

    public function __construct(Dispatcher $dispatcher)
    {
        $this->events = $dispatcher;
    }

    public function saving($model)
    {
        if ($model->isDirty(['payed']))
        {
            $this->payed($model->payed);
        }

        if ($model->isDirty(['sent']))
        {
            $this->payed($model->sent);
        }

        if ($model->isDirty(['received']))
        {
            $this->payed($model->received);
        }                
    }	

    public function payed($value)
    {
        //do stuff
    }

    public function sent($value)
    {
        //do stuff
    }

    public function received($value)
    {
        //do stuff
    }        


	public function created($model)
	{
		Session::flash('message', Lang::get('persian.add-product-success', array(), 'fa') );
	}


	public function updated($model)
	{
		Session::flash('message', Lang::get('persian.update-product-success', array(), 'fa'));
	}

	public function deleted($model)
	{
		Session::flash('message', Lang::get('persian.delete-product-success', array(), 'fa'));
	}

}

