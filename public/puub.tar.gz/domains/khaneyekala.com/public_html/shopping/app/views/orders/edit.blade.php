<?php include(app_path().'/views/orders/orders-view-create-variables.blade.php'); 
?>

<div>
	@include('partials.resource-edit' , $vars)
</div>