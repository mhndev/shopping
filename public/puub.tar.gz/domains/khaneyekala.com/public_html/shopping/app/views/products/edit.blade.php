{{ HTML::script('ckeditor/ckeditor.js') }}
{{ HTML::script('elfinder/js/elfinder.min.js') }}
{{ HTML::style('elfinder/css/theme.css') }}
{{ HTML::style('elfinder/css/elfinder.min.css') }}
{{ HTML::style('colorbox.css') }}
{{ HTML::script('jquery.colorbox-min.js') }}


<div>
<div class="row" style="float:right;">
<div class="col-lg-12">
<div class="row" >
  <div class="col-lg-12" >

        <h1>{{ Lang::get('persian.products-management', array(), 'fa') }}
            <small>
			{{ Lang::get('persian.edit-product', array(), 'fa') }}
            </small>
    	</h1>

        <ol class="breadcrumb">

          <li><a href="{{URL::to('admin/dashboard')}}">
          	<i class="fa fa-dashboard"></i> 
			{{ Lang::get('persian.admin-firstpage', array(), 'fa') }}
          </a></li>

          <li class="active">
          	<i class="fa fa-bar-chart-o"></i>
			{{ Lang::get('persian.products-management', array(), 'fa')  }}
          </li>

          <li class="active">
          	<i class="fa fa-dashboard"></i>
			{{ Lang::get('persian.edit-product', array(), 'fa') }}
          </li>

        </ol>
        @if(Session::has('message'))
        	<div class="alert alert-info alert-dismissable">
                {{ Session::get('message') }}
                <br>
            </div>
		@endif
    </div>
</div><!-- /.row -->

{{ Form::model($model,array('url' =>  array('admin/'.$model->category_id.'/products' , $model->id),'method' => 'PUT'))}}

<div class="col-lg-12 col-md-4 col-sm-6" style="float:right;">


@foreach( $columns as $column)
	<div class="row">
		<div class="col-md-10" style="float:right;">
		<div class="form-group">
			{{ Form::label($column ,Lang::get('persian.'.$column, array(), 'fa')) }}
			{{ Form::text($column ,Input::old($column), array('class' => 'form-control')) }}
		</div>
		</div>
	</div>
@endforeach	


	<div class="row">
        	<div class="col-md-4" style="float:right">
	        		<div class="form-group">
						{{
							Form::label('image_showProduct',
							Lang::get('persian.image_showProduct' ,array() , 'fa') , 
							array('class' => 'popup_selector btn btn-success',
							'data-inputid'=>'fileurl1',
							'style'=>'padding:7px; margin:3px;')	)
						}}

						{{
							Form::text('image_showProduct',Input::old('image_showProduct'),
								    array('class' => 'form-control','id'=>'fileurl1'))
						}}
					</div>
			</div>
	</div>


	<div class="row">
        	<div class="col-md-4" style="float:right">
	        		<div class="form-group">
						{{
							Form::label('image_products',
							Lang::get('persian.image_products' ,array() , 'fa') , 
							array('class' => 'popup_selector btn btn-success',
							'data-inputid'=>'fileurl2',
							'style'=>'padding:7px; margin:3px;')	)
						}}

						{{
							Form::text('image_products',Input::old('image_products'),
								    array('class' => 'form-control','id'=>'fileurl2'))
						}}
					</div>
			</div>
	</div>

	<div class="row">
        	<div class="col-md-4" style="float:right">
	        		<div class="form-group">
						{{
							Form::label('image_windows',
							Lang::get('persian.image_windows' ,array() , 'fa') , 
							array('class' => 'popup_selector btn btn-success',
							'data-inputid'=>'fileurl3',
							'style'=>'padding:7px; margin:3px;')	)
						}}

						{{
							Form::text('image_windows',Input::old('image_windows'),
								    array('class' => 'form-control','id'=>'fileurl3'))
						}}
					</div>
			</div>
	</div>	


	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_big1',Lang::get('persian.image_big1' ,array() , 'fa') , 
					array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl4','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_big1',Input::old('image_big1'),
						    array('class' => 'form-control','id'=>'fileurl4')) }}
			</div>
		</div>
	</div>		


	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_big2',Lang::get('persian.image_big2' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl5','style'=>'padding:7px; margin:3px;')) }}

				{{ Form::text('image_big2',Input::old('image_big2'),
						    array('class' => 'form-control','id'=>'fileurl5')) }}
			</div>
		</div>
	</div>	


	<div class="row">
        <div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_big3',Lang::get('persian.image_big3' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl6','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_big3',Input::old('image_big3'),
						    array('class' => 'form-control','id'=>'fileurl6')) }}
			</div>
		</div>
	</div>	


	<div class="row">
		<div class="col-md-4" style="float:right">
			<div class="form-group">
				{{Form::label('image_big4',Lang::get('persian.image_big4' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl7','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_big4',Input::old('image_big4'),
						    array('class' => 'form-control','id'=>'fileurl7')) }}
			</div>
		</div>
	</div>	



	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_big5',Lang::get('persian.image_big5' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl8','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_big5',Input::old('image_big5'),
						    array('class' => 'form-control','id'=>'fileurl8'))}}
			</div>
		</div>
	</div>	






	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_small1',Lang::get('persian.image_small1' ,array() , 'fa') , 
					array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl9','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_small1',Input::old('image_small'),
						    array('class' => 'form-control','id'=>'fileurl9')) }}
			</div>
		</div>
	</div>		


	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_small2',Lang::get('persian.image_small2' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl10','style'=>'padding:7px; margin:3px;')) }}

				{{ Form::text('image_small2',Input::old('image_small2'),
						    array('class' => 'form-control','id'=>'fileurl10')) }}
			</div>
		</div>
	</div>	


	<div class="row">
        <div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_small3',Lang::get('persian.image_small3' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl11','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_small3',Input::old('image_small3'),
						    array('class' => 'form-control','id'=>'fileurl11')) }}
			</div>
		</div>
	</div>	


	<div class="row">
		<div class="col-md-4" style="float:right">
			<div class="form-group">
				{{Form::label('image_small4' , Lang::get('persian.image_small4' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl12','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_small4',Input::old('image_small4'),
						    array('class' => 'form-control','id'=>'fileurl12')) }}
			</div>
		</div>
	</div>	



	<div class="row">
    	<div class="col-md-4" style="float:right">
    		<div class="form-group">
				{{ Form::label('image_small5',Lang::get('persian.image_small5' ,array() , 'fa') , array('class' => 'popup_selector btn btn-success',
					'data-inputid'=>'fileurl13','style'=>'padding:7px; margin:3px;')	) }}

				{{ Form::text('image_small5',Input::old('image_small5'),
						    array('class' => 'form-control','id'=>'fileurl13'))}}
			</div>
		</div>
	</div>	





	<div class="row">
		<div class="col-md-10" style="float:right;">
		<div class="form-group">
			{{ Form::label('description' ,Lang::get('persian.description', array(), 'fa')) }}
			{{ Form::textarea('description' ,Input::old('description'), array('class' => 'form-control')) }}
		</div>
		</div>
	</div>


<div class="row" style="float:right;"><div class="col-md-4" style="width:200px;">
{{Form::submit(Lang::get('persian.submit', array(), 'fa'), array('class'=> 'btn btn-primary' , 'style'=>'width:100px; margin-bottom:45px; margin-top:30px;'))}}
	</div>
</div></div>
	{{Form::close()}}


<script>
CKEDITOR.replace( 'description', {
    filebrowserBrowseUrl : '/shopping/public/elfinder/elfinder.html', 
    uiColor : '#9AB8F3',
});
</script>



</div>
</div>


{{ HTML::script('packages/barryvdh/laravel-elfinder/js/standalonepopup.min.js') }}









</div>

{{ HTML::script('js/libjs/completeform.js') }}

<script type="text/javascript">

</script>