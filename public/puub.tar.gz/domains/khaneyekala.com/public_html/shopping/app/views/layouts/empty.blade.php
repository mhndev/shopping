<!DOCTYPE html>
<html class="rtl" lang="en">
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<head>
	<meta name="viewport" content="width=device-width">
	<meta charset="UTF-8" />
	<title>{{ Lang::get('persian.khaneye-kala' , array() , 'fa') }}</title>

	<body>
		<section id="page" class="offcanvas-pusher" role="main">
			{{ $content }}
		</section>
	</body>
</html>