<div id="viewContainer" style="margin:auto; width:950px; direction:rtl;text-align:right">
	<div>
		{{ $menu->faname }}
	</div>

	<div>
		{{ $menu->body }}
	</div>
</div>

<div style="clear:both"></div>