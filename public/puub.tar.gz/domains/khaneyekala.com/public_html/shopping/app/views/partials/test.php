 {{ Lang::get('persian.guideBuyFromKhaneyekala' , array() , 'fa') }}
 {{ Lang::get('persian.whyKhaneyekala' , array() , 'fa') }}
 {{ Lang::get('persian.commonQuestions' , array() , 'fa') }}
 {{ Lang::get('persian.khaneyeKalaNews' , array() , 'fa') }}
 {{ Lang::get('persian.contactUs' , array() , 'fa') }}
 {{ Lang::get('persian.aboutUs' , array() , 'fa') }}
 {{ Lang::get('persian.joinUs' , array() , 'fa') }}
 {{ Lang::get('persian.khaneyeKalaEmploy' , array() , 'fa') }}
 {{ Lang::get('persian.situationsAndLaws' , array() , 'fa') }}
 {{ Lang::get('persian.payways' , array() , 'fa') }}
 {{ Lang::get('persian.turnBackProductWay' , array() , 'fa') }}
 {{ Lang::get('persian.homePage' , array() , 'fa') }}
 {{ Lang::get('persian.jahizie' , array() , 'fa') }}
 {{Lang::get('persian.specialSuggest' , array() , 'fa')   }}
 {{Lang::get('persian.newestProducts' , array() , 'fa')   }}  