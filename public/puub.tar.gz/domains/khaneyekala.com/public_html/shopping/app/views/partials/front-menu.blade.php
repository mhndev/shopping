<div class="custom-menu">
<div id="pav-mainnav">			
<div class="container" style="width:980px;">

<div class="pav-megamenu">
<div class="navbar navbar-default">
<div id="mainmenutop" class="megamenu" role="navigation">
<div class="navbar-header">
<a href="javascript:;" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle">
<span class="fa fa-bars"></span>		        
</a>
<div class="collapse navbar-collapse navbar-ex1-collapse">
<ul class="nav navbar-nav megamenu">
<li style="width:80px;" class="home" >
<a href="{{ URL::to('/Refrigerator-Freezer') }}">

	{{ HTML::image('front/image/nav.png','a picture', array('class' => 'nav-img')) }}
</a>
</li>

<li style="width:80px;" class="" >
<a href="{{ URL::to('/Washing-Machines') }}">
	{{ HTML::image('front/image/nav6.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>
<li style="width:80px;" class="" >
<a href="{{ URL::to('/Spilet') }}">
	{{ HTML::image('front/image/nav2.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>

<li style="width:80px;" class="" >
<a href="{{ URL::to('/TV') }}">
    {{ HTML::image('front/image/nav3.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>

<li style="width:80px;" class="" >
<a href="{{ URL::to('/Iron') }}">

    {{ HTML::image('front/image/nav4.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>

<li style="width:80px;" class="" >
<a href="{{ URL::to('/Stove') }}">
    {{ HTML::image('front/image/nav5.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>
<li style="width:80px;" class="" >
<a href="{{ URL::to('/Heater') }}">
    {{ HTML::image('front/image/nav7.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>

<li style="width:80px;" class="" >
<a href="">
    {{ HTML::image('front/image/nav.png' , '' , array('class'=>'nav-img')) }}
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>				
</div>					
</div>
</div>