
<div class="title">
{{ HTML::image('images/3.jpg') }}
</div>
<div class="sample-products flexslider">
<ul class="slides">
<li class="">
    <a href="#">
{{ HTML::image('images/image/5/t51p_schraeg.jpg') }}

        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
      <div>نام<div>
      <span class="green">795,000 تومان</span>
    </a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
<li class="">
    <a href="#">
      {{ HTML::image('images/image/5/t51p_schraeg.jpg') }}
        <span>نام</span></a>
</li>
</ul>
</div>
<script>
jQuery(function(){
jQuery('.sample-products').flexslider({
animation: "slide",
itemWidth: 120,
itemMargin: 5,
controlNav: false
});
jQuery('.more-views').flexslider({
animation: "slide",
itemWidth: 50,
itemMargin: 5,
controlNav: false
});

});
</script>