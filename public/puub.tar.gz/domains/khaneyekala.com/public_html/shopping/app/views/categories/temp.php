


var lang = {{json_encode($lang)}};

khate bala bad az khate payeen biaiad

var features = {{($model->features)}};