
<?php 
require_once(app_path().'/views/sells/sells-view-create-variables.blade.php');

?>

<div>
	@include('partials.resource-edit' , $vars)
</div>