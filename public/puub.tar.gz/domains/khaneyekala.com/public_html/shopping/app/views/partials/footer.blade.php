<div class="row" style="float:right;"><div class="col-md-4" style="width:200px;">
{{Form::submit(Lang::get('persian.submit', array(), 'fa'), array('class'=> 'btn btn-primary' , 'style'=>'width:100px; margin-bottom:45px; margin-top:30px;'))}}
	</div>
</div></div>
	{{Form::close()}}
</div></div>