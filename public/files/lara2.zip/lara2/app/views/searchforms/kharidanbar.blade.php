

{{ Form::open(array('url' => 'getform' , 'method' => 'GET')) }}


     {{ Form::label('tedade-sule','تعداد سوله:',array('id'=>'myId1','class'=>'myClass1')) }}
     {{ Form::text('tedade-sule') }}
     <br>

     {{ Form::label('metraje-kol','متراژ کل:',array('id'=>'myId2','class'=>'myClass2')) }}
     {{ Form::text('metraj-kol') }}
     <br>

     {{ Form::label('tedade-sule','جنس کف انبار:',array('id'=>'myId3','class'=>'myClass3')) }}
     {{ Form::select('jense-kafe-anbar', array(
       'facebook' => 'Facebook',
       'twitter' => 'Twitter',
       'cribbb' => 'Cribbb'
     ) , null , array('class' => 'form-control' )) }}
     <br>

     {{ Form::label('lifterak','لیفتراک:',array('id'=>'myId4','class'=>'myClass4')) }}
     {{ Form::checkbox('lifterak', 'yes', false) }}
     <br>

     {{ Form::label('jarsaghil','جرثقیل:',array('id'=>'myId5','class'=>'myClass5')) }}
     {{ Form::checkbox('jarsaghil', 'yes', false) }}
     <br>

     {{ Form::label('metraje-edari','متراژ اداری:',array('id'=>'myId6','class'=>'myClass6')) }}
     {{ Form::checkbox('metraje-edari', 'yes', false) }}
     <br>

     {{ Form::label('metraje-hayat','متراژ حیاط:',array('id'=>'myId7','class'=>'myClass7')) }}
     {{ Form::checkbox('metraje-hayat', 'yes', false) }}
     <br>

     {{ Form::label('hefaz','حفاظ:',array('id'=>'myId8','class'=>'myClass8')) }}
     {{ Form::checkbox('hefaz', 'yes', false) }}
     <br>

     {{ Form::label('kapsule-atashneshani','کپسول آتش مشانی:',array('id'=>'myId9','class'=>'myClass9')) }}
     {{ Form::checkbox('kapsule-atashneshani', 'yes', false) }}
     <br>

     {{ Form::label('durbin-madarbaste','دوربین مدار بسته:',array('id'=>'myId10','class'=>'myClass10')) }}
     {{ Form::checkbox('durbin-madarbaste', 'yes', false) }}
     <br>




     {{ Form::submit('جستجو') }}

{{ Form::close() }}