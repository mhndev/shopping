

{{ Form::open(array('url' => 'getform' , 'method' => 'GET')) }}

     {{ Form::label('kargahi','کارگاهی:',array('id'=>'myId1','class'=>'myClass1')) }}
     {{ Form::checkbox('kargahi', 'yes', false) }}
     <br>

     {{ Form::label('barandaz','بارانداز:',array('id'=>'myId2','class'=>'myClass2')) }}
     {{ Form::checkbox('barandaz', 'yes', false) }}
     <br>

     {{ Form::label('barghe3fazechandwhat','برق سه فار چند وات:',array('id'=>'myId3','class'=>'myClass3')) }}
     {{ Form::text('barghe3fazechandwhat') }}
     <br>

     {{ Form::label('metraj','متراژ:',array('id'=>'myId4','class'=>'myClass4')) }}
     {{ Form::text('metraj') }}

     <br>

     {{ Form::label('parvaneh','پروانه:',array('id'=>'myId5','class'=>'myClass5')) }}
     {{ Form::select('parvaneh', array(
       'food' => 'مواد غذایی',
       'building' => 'مصالح ساختمانی',
       'alvar' => 'الوار'
     ) , null , array('class' => 'form-control' )) }}     
     <br>

     {{ Form::label('jense-kaf','جنس کف:',array('id'=>'myId6','class'=>'myClass6')) }}
     {{ Form::checkbox('jense-kaf', 'yes', false) }}
     <br>


     {{ Form::label('lifterak','لیفتراک:',array('id'=>'myId8','class'=>'myClass8')) }}
     {{ Form::checkbox('lifterak', 'yes', false) }}
     <br>

     {{ Form::label('jarsaghil','جرثقیل:',array('id'=>'myId9','class'=>'myClass9')) }}
     {{ Form::checkbox('jarsaghil', 'yes', false) }}
     <br>

     {{ Form::label('hefaz','حفاظ:',array('id'=>'myId10','class'=>'myClass10')) }}
     {{ Form::checkbox('hefaz', 'yes', false) }}
     <br>

     {{ Form::label('negahban','نگهبان:',array('id'=>'myId11','class'=>'myClass11')) }}
     {{ Form::checkbox('negahban', 'yes', false) }}
     <br>

     {{ Form::label('manbae-ab','منبع آب:',array('id'=>'myId12','class'=>'myClass12')) }}
     {{ Form::checkbox('manbae-ab', 'yes', false) }}
     <br>

     {{ Form::label('کپسول آتش نشانی','کپسول آتش مشانی:',array('id'=>'myId13','class'=>'myClass13')) }}
     {{ Form::checkbox('kapsule-atashneshani', 'yes', false) }}
     <br>

     {{ Form::label('durbin-madarbaste','دوربین مدار بسته:',array('id'=>'myId14','class'=>'myClass14')) }}
     {{ Form::checkbox('durbin-madarbaste', 'yes', false) }}
     <br>




     {{ Form::submit('جستجو') }}

{{ Form::close() }}