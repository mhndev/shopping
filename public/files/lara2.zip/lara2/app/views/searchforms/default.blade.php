@extends('layouts.index')


@section('content')

<!--
     {{ Form::label('ejare','ejare:',array('id'=>'myId1','class'=>'myClass1')) }}
     {{ Form::radio('ejare-kharid' , 'ejare' , false) }}


     {{ Form::label('kharid','kharid:',array('id'=>'myId1','class'=>'myClass1')) }}
     {{ Form::radio('ejare-kharid' , 'kharid' , false) }}
-->

<div id="search-container" style="width:250px; margin-bottom:30px;">

<h2 style="font-family: Open Sans;color: #4a4786; margin-bottom:10px;">جستجوی پیشرفته :</h2>
 <label for="ejare"  class="ejare" >اجاره</label>   
 <input id="ejare" name="ejare-kharid" type="radio" value="ejare" onclick="openme()">




<label for="kharid" class="kharid">خرید</label>   
<input id="kharid" name="ejare-kharid" type="radio" value="kharid"  onclick="openme()">



<select id="selectme" class="form-control"  style="display:none; font-family:Open Sans;" onchange="loadhireform()" >
  <option value="">--------</option>
  <option value="ejare-anbar" style="font-family:Open Sans">اجاره انبار</option>
  <option value="ejare-hayat" style="font-family:Open Sans">اجاره حیاط</option>
  <option value="ejare-sule" style="font-family:Open Sans">اجاره سوله</option>
</select>

<div id="myDiv"></div>


{{ HTML::script('js/test.js') }}
@stop

</div>


 



