

{{ Form::open(array('url' => 'getform' , 'method' => 'GET')) }}

     {{ Form::label('darbast','دربست:',array('id'=>'myId1','class'=>'myClass1')) }}
     {{ Form::checkbox('darbast', 'yes', false) }}
     <br>

	{{ Form::label('metraje-daftari','تعداد سوله:',array('id'=>'myId2','class'=>'myClass2')) }}
     {{ Form::text('metraje-daftari') }}
     <br>

     {{ Form::label('barghe3fazechandwhat','برق سه فاز چند وات:',array('id'=>'myId3','class'=>'myClass3')) }}
     {{ Form::text('barghe3fazechandwhat') }}
     <br>

     {{ Form::label('metraj','متراژ:',array('id'=>'myId4','class'=>'myClass4')) }}
     {{ Form::text('metraj') }}

     <br>

	{{ Form::label('parvaneh','پروانه:',array('id'=>'myId5','class'=>'myClass5')) }}
     {{ Form::select('parvaneh', array(
       'food' => 'مواد غذایی',
       'building' => 'مصالح ساختمانی',
       'alvar' => 'الوار'
     ) , null , array('class' => 'form-control' )) }}     
     <br>

     {{ Form::label('jense-kaf','جنس کف:',array('id'=>'myId6','class'=>'myClass6')) }}
     {{ Form::checkbox('jense-kaf', 'yes', false) }}
     <br>

     {{ Form::label('ertefae-sule','ارتفاع سوله:',array('id'=>'myId7','class'=>'myClass7')) }}
     {{ Form::checkbox('ertefae-sule', 'yes', false) }}
     <br>

     {{ Form::label('lifterak','لیفتراک:',array('id'=>'myId8','class'=>'myClass8')) }}
     {{ Form::checkbox('lifterak', 'yes', false) }}
     <br>

     {{ Form::label('jarsaghil','جرثقیل:',array('id'=>'myId9','class'=>'myClass9')) }}
     {{ Form::checkbox('jarsaghil', 'yes', false) }}
     <br>

     {{ Form::label('hefaz','حفاظ:',array('id'=>'myId10','class'=>'myClass10')) }}
     {{ Form::checkbox('hefaz', 'yes', false) }}
     <br>

     {{ Form::label('negahban','نگهبان:',array('id'=>'myId11','class'=>'myClass11')) }}
     {{ Form::checkbox('negahban', 'yes', false) }}
     <br>

     {{ Form::label('manbae-ab','منبع آب:',array('id'=>'myId12','class'=>'myClass12')) }}
     {{ Form::checkbox('manbae-ab', 'yes', false) }}
     <br>

     {{ Form::label('kapsule-atashneshani','کپسول آتش مشانی:',array('id'=>'myId13','class'=>'myClass13')) }}
     {{ Form::checkbox('kapsule-atashneshani', 'yes', false) }}
     <br>

     {{ Form::label('durbin-madarbaste','دوربین مدار بسته:',array('id'=>'myId14','class'=>'myClass14')) }}
     {{ Form::checkbox('durbin-madarbaste', 'yes', false) }}
     <br>




     {{ Form::submit('جستجو') }}

{{ Form::close() }}