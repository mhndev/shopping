<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="ANBARYAB">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ANBARYAB | KHARID EJARE</title>
        <!-- html5 support in IE8 and later -->
        {{ HTML::script('../../html5shiv.googlecode.com/svn/trunk/html5.js') }}
        <!-- CSS file links -->


        {{ HTML::style('frontend/css/bootstrap.min.css') }}
        {{ HTML::style('frontend/css/style.css') }}
        {{ HTML::style('frontend/css/responsive.css') }}
        {{ HTML::style('frontend/css/yamm.css') }}
        {{ HTML::style('frontend/css/jquery.nouislider.min.css') }}


        {{ HTML::script('http://fonts.googleapis.com/css?family=Open+Sans:700') }}

        {{ HTML::style('frontend/css/owl.carousel.css') }}
        {{ HTML::style('frontend/css/owl.theme.css') }}
        {{ HTML::style('frontend/css/jquery.bxslider.css') }}

    </head>

    <body>

        <!-- Start Header -->
        <header class="navbar yamm navbar-default navbar-fixed-top" >
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse" >
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        انبار
                        <span>
                            یاب
                        </span></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="#" class="current" data-toggle="dropdown">
                                صفحه اصلی‌
                            </a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown" style="width: 135px">
                                جست و جو پیشرفت
                            </a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">
                                سپردن انبار
                            </a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">
                                درخواست انبار
                            </a>
                        </li>
                        <li>
                            <a href="#"  data-toggle="dropdown">
                                تماس با ما
                            </a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">
                                درباره ما
                            </a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">
                                راهنما
                            </a>
                        </li>
                        <li>
                            <ul class="nav navbar-nav userButtons">
                                <li><div class="verticalDivider"></div></li>
                                <li><a href="#" class="dropdown-toggle buttonGrey">
                                        ثبتنام
                                    </a></li>
                                <li><a style="margin-right:0px;" href="#" class="dropdown-toggle buttonGrey">
                                        ورود
                                    </a></li>
                            </ul>
                        </li>
                    </ul>        
                </div><!--/.navbar-collapse -->
            </div><!-- end header container -->
        </header><!-- End Header -->

        <!-- start subheader -->
        <section class="subHeader page">
            <div class="container" style="margin-bottom: 50px">
                <h1 >
                    تیتر برای صفحه
                </h1>
                <form class="searchForm" method="post" action="#">
                    <input type="text" name="search" value="Search our site" />
                </form>
            </div><!-- end subheader container -->
        </section><!-- end subheader section -->


        <!-- start horizontal filter -->
        <section class="filter" style="margin-bottom: 50px;">
            <div class="container">
                <div class="filterHeader">
                    <ul class="filterNav tabs">
                        <li><a class="current triangle" href="#tab1">
                                همه موارد
                            </a></li>
                        <li><a href="#tab2">
                                برای فروش
                            </a></li>
                            <li><a href="#tab3">
                                برای اجاره
                            </a></li>
                    </ul>
                    <div class="filterHeadButton"><a class="buttonGrey" href="#">
                            جست و جو پیشرفت
                        </a></div>
                </div>
                <div class="filterContent" id="tab1">
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">
                                        محدوده مکانی
                                    </label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">
                                        متراژ
                                    </label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock" style="direction: ltr">
                                    <label for="price-min" class="pricelabel">
                                        محدوده قیمت
                                    </label><br/>
                                    <div style="float:right; margin-top:-25px;">
                                        <div class="priceInput"><input type="text" name="price min" id="price-min" class="priceInput" /></div>
                                        <span style="float:left; margin-right:10px; margin-left:10px;">-</span>
                                        <div class="priceInput"><input type="text" name="price max" id="price-max" class="priceInput" /></div>
                                    </div><br/>
                                    <div class="priceSlider"></div>
                                    <div class="priceSliderLabel"><span>0</span><span style="float:right;">800,000</span></div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">
                                        ملک
                                    </label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">
                                        انبار
                                    </label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">
                                        مساحت
                                    </label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="بیاب" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB1 -->
                <div class="filterContent" id="tab2">
                    <p>
                        توضیحات
                    </p>
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">
                                        محدوده مکانی
                                    </label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">
                                        متراژ
                                    </label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMinDropDown">
                                        مینیمم قیمت
                                    </label><br/>
                                    <select name="priceMinDropdown" id="priceMinDropDown" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="$100,000">$100,000</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$800,000">$800,000</option>
                                        <option value="$900,000">$900,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMaxDropdown">
                                        ماکسیمم قیمت
                                    </label><br/>
                                    <select name="priceMaxDropdown" id="priceMaxDropdown" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$700,000">$700,000</option>
                                        <option value="$900,000">$900,000</option>
                                        <option value="$1,000,000">$1,000,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">
                                        ملک
                                    </label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">
                                        انبار
                                    </label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">
                                        مساحت
                                    </label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="بیاب" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB 2 -->
                <div class="filterContent" id="tab3">
                    <p>
                        توضیحات
                    </p>
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">
                                        محدوده مکانی
                                    </label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">
                                        متراژ
                                    </label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMinDropDown">
                                        مینیمم قیمت
                                    </label><br/>
                                    <select name="priceMinDropdown" id="priceMinDropDown" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="$100,000">$100,000</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$800,000">$800,000</option>
                                        <option value="$900,000">$900,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMaxDropdown">
                                        ماکسیمم قیمت
                                    </label><br/>
                                    <select name="priceMaxDropdown" id="priceMaxDropdown" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$700,000">$700,000</option>
                                        <option value="$900,000">$900,000</option>
                                        <option value="$1,000,000">$1,000,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">
                                        ملک
                                    </label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">
                                        انبار
                                    </label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">
                                        مساحت
                                    </label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">
                                            همه
                                        </option>
                                        <option value="Family Home">
                                            زیر مجموعه
                                        </option>
                                        <option value="Apartment">
                                            زیر مجموعه
                                        </option>
                                        <option value="Condo">
                                            زیر مجموعه
                                        </option>
                                        <option value="Villa">
                                            زیر مجموعه
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="بیاب" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB 3 -->
            </div><!-- END CONTAINER -->
        </section>
        <!-- end horizontal filter -->

        <!-- start recent properties -->
        <section class="properties">
            <div class="container">
                        <div class="container">
                            @yield('content')
                        </div>

                <h3>
                    تازه ها
                </h3>
                <div class="divider"></div>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">
                                    انبار
                                </a>
                                <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                    <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-check.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                </tr>
                            </table> 
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">
                                    انبار
                                </a>
                                <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                    <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-check.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                </tr>
                            </table> 
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">
                                    انبار
                                </a>
                                <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:5px;" />2,412m</td>
                                    <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-check.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                </tr>
                            </table> 
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">
                                    انبار
                                </a>
                                <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>

                                <div class="divider thin"></div>
                                 <p class="forSale">
                                    برای فروش
                                </p>
                                <p>
                                    مالک
                                </p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                    <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                        ویژگی‌
                                    </td>
                                    <td><img src="frontend/images/icon-check.png" alt="" style="margin-right:5px;" />
                                        ویژگی‌
                                    </td>
                                </tr>
                            </table> 
                        </div>
                    </div>

                </div><!-- end row -->
            </div><!-- end container -->
        </section>
        <!-- end recent properties -->

        <!-- start services section -->
        <section class="services" style="direction: ltr">
            <div class="container">
                <h3>
                    تبلیغات 
                </h3>
                <div class="divider"></div>
                <div class="row">
                    <ul class="owl-carousel" id="carousel" data-columns="6" data-autoplay="yes" data-pagination="no" data-arrows="yes" data-single-item="no" data-items-desktop="6" data-items-desktop-small="4" data-items-mobile="2" data-items-tablet="4">
                        <li class="item"> <a href="#"><img src="frontend/images/partner-1.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-2.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-4.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-5.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-1.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-2.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-4.png" alt=""></a> </li>
                        <li class="item"> <a href="#"><img src="frontend/images/partner-5.png" alt=""></a> </li>
                    </ul>
                </div>

            </div><!-- end container -->
        </section>
        <!-- end services section -->

        <!-- start  section -->
        <section class="Lux" style="direction: ltr">
            <div class="container">
                <h2 style="float: right; border-bottom: 6px white solid; margin-top: -10px"><span>LUXUARY</span></h2><br><br>
                <div class="divider"></div>

                <div class="row">
                    <div id="carouselproperties" class="property-carousel widget">

                        <div class="carousel">
                            <ul class="bxslider">
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                1     انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                2  انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div> 
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                3   انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div> 
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                4     انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div> 
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                5 انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div> 
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                6    انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>                                
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                7 انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>                                
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                8   انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                9     انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>
                                </li>
                                <li>
                                    <div class="propertyItem">
                                        <div class="propertyContent">
                                            <a class="propertyType" href="#">
                                                10   انبار
                                            </a>
                                            <a href="#" class="propertyImgLink"><img class="propertyImg" src="frontend/images/home1.jpg" alt="" /></a>
                                            <h4><a href="#">
                                                    آدرس
                                                </a></h4>
                                            <p>
                                                مالک
                                            </p>
                                            <div class="divider thin"></div>
                                            <p class="forSale">
                                                برای فروش
                                            </p>
                                            <p class="price">$687,000</p>
                                        </div>
                                        <table border="1" class="propertyDetails">
                                            <tr>
                                                <td><img src="frontend/images/icon-area.png" alt="" style="margin-right:7px;" />2,412m</td>
                                                <td><img src="frontend/images/icon-bed.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                                <td><img src="frontend/images/icon-drop.png" alt="" style="margin-right:7px;" />
                                                    ویژگی‌
                                                </td>
                                            </tr>
                                        </table> 
                                    </div>
                                </li>
                            </ul>
                        </div>


                    </div><!-- /.end -->

                </div>
            </div>
        </section>
        <!-- end  section -->

        <!-- start call to action -->
        <section class="callToAction" style="margin-top: 50px">
            <div class="container">
                <div class="ctaBox">
                    <div class="col-lg-9">
                        <h1>
                            همین امروز با ما
                            <span>
                                تماس
                            </span> 
                            بگیرید
                        </h1>
                        <p>
                            متن مورد نظر برای بر قراری ارتباط با مشتری اینجا قرار می‌گیرد
                        </p>
                    </div>
                    <div class="col-lg-3">
                        <a style="float:right; margin-top:15px;" class="buttonColor" href="#">
                            تماس با ما
                        </a>
                    </div>
                    <div style="clear:both;"></div>
                </div>
            </div>
        </section>
        <!-- end call to action -->

        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <h4><a class="footerLogo" href="#">
                                انبار
                                <span>
                                    یاب
                                </span></a></h4>
                        <p>
                            متن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظر
                            متن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظر
                            متن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظرمتن مورد نظر
                        </p>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <h4>
                            تماس
                        </h4>
                        <ul class="contactList">
                            <li><img class="icon" src="frontend/images/icon-pin.png" alt="" /> 
                                آدرس
                            </li>
                            <li><img class="icon" src="frontend/images/icon-phone.png" alt="" /> 
                                شماره
                            </li>
                            <li><img class="icon" src="frontend/images/icon-mail.png" alt="" /> hello@something.com</li>
                        </ul>
                    </div>


                </div><!-- end row -->
            </div><!-- end footer container -->
        </footer>

        <div class="bottomBar">
            <div class="container">
                <p>ANBAR YAB COPYRIGHT 2014</p>
                <ul class="socialIcons">
                    <li><a href="#"><img src="frontend/images/icon-fb.png" alt="" /></a></li>
                    <li><a href="#"><img src="frontend/images/icon-twitter.png" alt="" /></a></li>
                    <li><a href="#"><img src="frontend/images/icon-google.png" alt="" /></a></li>
                    <li><a href="#"><img src="frontend/images/icon-rss.png" alt="" /></a></li>
                </ul>
            </div>
        </div>

        <!-- JavaScript file links -->
        <script src="frontend/js/jquery-1.9.1.min.js"></script>			<!-- Jquery -->
        <script src="frontend/js/owl.carousel.min.js"></script>
        <script src="frontend/js/bootstrap.min.js"></script>  <!-- bootstrap 3.0 -->
        <script src="frontend/js/respond.js"></script>
        <script src="frontend/js/tabs.js"></script>       <!-- tabs -->
        <script src="frontend/js/jquery.nouislider.min.js"></script>  <!-- price slider -->
        <script src="frontend/js/jquery.bxslider.min.js"></script> 


        <script>
            //Setup price slider 
            var Link = $.noUiSlider.Link;

            $(".priceSlider").noUiSlider({
                range: {
                    'min': 0,
                    'max': 800000
                }
                ,start: [150000, 550000]
                ,step: 1000
                ,margin: 100000
                ,connect: true
                ,direction: 'ltr'
                ,orientation: 'horizontal'
                ,behaviour: 'tap-drag'
                ,serialization: {
                    lower: [
                        new Link({
                            target: $("#price-min")
                        })
                    ],

                    upper: [
                        new Link({
                            target: $("#price-max")
                        })
                    ],

                    format: {
                        // Set formatting
                        decimals: 0,
                        thousand: ',',
                        prefix: '$'
                    }
                }
            });
            
            
        </script>

        <script>
            $('.owl-carousel').each(function(){
                var carouselInstance = $(this); 
                carouselColumns = carouselInstance.attr("data-columns") ? carouselInstance.attr("data-columns") : "1",
                carouselitemsDesktop = carouselInstance.attr("data-items-desktop") ? carouselInstance.attr("data-items-desktop") : "4",
                carouselitemsDesktopSmall = carouselInstance.attr("data-items-desktop-small") ? carouselInstance.attr("data-items-desktop-small") : "3",
                carouselitemsTablet = carouselInstance.attr("data-items-tablet") ? carouselInstance.attr("data-items-tablet") : "2",
                carouselitemsMobile = carouselInstance.attr("data-items-mobile") ? carouselInstance.attr("data-items-mobile") : "1",
                carouselAutoplay = carouselInstance.attr("data-autoplay") == 'yes' ? true : false,
                carouselPagination = carouselInstance.attr("data-pagination") == 'yes' ? true : false,
                carouselArrows = carouselInstance.attr("data-arrows") == 'yes' ? true : false,
                carouselSingle = carouselInstance.attr("data-single-item") == 'yes' ? true : false
                carouselStyle = carouselInstance.attr("data-style") ? carouselInstance.attr("data-style") : "fade",
				
                carouselInstance.owlCarousel({
                    items: carouselColumns,
                    autoPlay : carouselAutoplay,
                    navigation : carouselArrows,
                    pagination : carouselPagination,
                    itemsDesktop:[1199,carouselitemsDesktop],
                    itemsDesktopSmall:[979,carouselitemsDesktopSmall],
                    itemsTablet:[768,carouselitemsTablet],
                    itemsMobile:[479,carouselitemsMobile],
                    singleItem:carouselSingle,
                    navigationText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
                    stopOnHover: true,
                    lazyLoad: true,
                    transitionStyle: carouselStyle
                });
            });
        </script>

        <script>
            $('.bxslider').bxSlider({
                minSlides: 1,
                maxSlides: 4,
                slideWidth: 280,
                slideMargin: 10,
                moveSlides: 2,
                auto: true
            });
        </script>
    </body>

</html>
