<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="ANBARYAB">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ANBARYAB | KHARID EJARE</title>
        <!-- html5 support in IE8 and later -->
        {{ HTML::script('../../html5shiv.googlecode.com/svn/trunk/html5.js') }}
        <!-- CSS file links -->


        {{ HTML::style('frontend/css/bootstrap.min.css') }}
        {{ HTML::style('frontend/css/style.css') }}
        {{ HTML::style('frontend/css/responsive.css') }}
        {{ HTML::style('frontend/css/yamm.css') }}
        {{ HTML::style('frontend/css/jquery.nouislider.min.css') }}

        {{ HTML::script('http://fonts.googleapis.com/css?family=Open+Sans:700') }}
    </head>

    <body>

        <!-- Start Header -->
        <header class="navbar yamm navbar-default navbar-fixed-top">
            <div class="container">



                <div class="navbar-header">
                    <a class="navbar-brand" href="#">ANBAR <span>YAB</span></a>
                </div>
                <div class="navbar-collapse collapse" >
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="#" class="current" data-toggle="dropdown">HOME</a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">SEARCH</a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">SEPORTAN ANBAR</a>
                        </li>
                        <li>
                            <a href="#" data-toggle="dropdown">DARKHAST ANBAR</a>
                        </li>
                        <li>
                            <a href="#"  data-toggle="dropdown">CONTACT</a>
                        </li>
                        <li>
                            <a href="#" class="dropdown-toggle">ABOUT US</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" data-toggle="dropdown">RAHNAMA</a>
                        </li>
                        <li>
                            <ul class="nav navbar-nav userButtons">
                                <li><div class="verticalDivider"></div></li>
                                <li><a href="#" class="dropdown-toggle buttonGrey">LOGIN</a></li>
                                <li><a style="margin-right:0px;" href="#" class="dropdown-toggle buttonGrey">REGISTER</a></li>
                            </ul>
                        </li>
                    </ul>        
                </div><!--/.navbar-collapse -->
            </div><!-- end header container -->
        </header><!-- End Header -->

        <!-- start subheader -->
        <section class="subHeader page">
            <div class="container" style="margin-bottom: 20px">
                <h1 >TITLE BARAY SAFE</h1>
                <form class="searchForm" method="post" action="#">
                    <input type="text" name="search" value="Search our site" />
                </form>
            </div><!-- end subheader container -->
        </section><!-- end subheader section -->


        <!-- start horizontal filter -->
        <section class="filter" style="margin-bottom: 50px;">
            <div class="container">
                <div class="filterHeader">
                    <ul class="filterNav tabs">
                        <li><a class="current triangle" href="#tab1">ALL PROPERTIES</a></li>
                        <li><a href="#tab2">FOR SALE</a></li>
                        <li><a href="#tab3">FOR RENT</a></li>
                    </ul>
                    <div class="filterHeadButton"><a class="buttonGrey" href="#">ADVANCE SEARCH</a></div>
                </div>
                <div class="filterContent" id="tab1">
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">MAHDOODE MAKANI</label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Family Home">SUB</option>
                                        <option value="Apartment">SUB</option>
                                        <option value="Condo">SUB</option>
                                        <option value="Villa">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">METRAJ</label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>

                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock" style="direction: ltr">
                                    <label for="price-min">Price Range</label><br/>
                                    <div style="float:right; margin-top:-25px;">
                                        <div class="priceInput"><input type="text" name="price min" id="price-min" class="priceInput" /></div>
                                        <span style="float:left; margin-right:10px; margin-left:10px;">-</span>
                                        <div class="priceInput"><input type="text" name="price max" id="price-max" class="priceInput" /></div>
                                    </div><br/>
                                    <div class="priceSlider"></div>
                                    <div class="priceSliderLabel"><span>0</span><span style="float:right;">800,000</span></div>
                                </div>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">MELK</label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">SUB</option>
                                        <option value="2">SUB</option>
                                        <option value="3">SUB</option>
                                        <option value="4">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">ANBAR</label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">Area</label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="FIND PROPERTIES" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB1 -->
                <div class="filterContent" id="tab2">
                    <p>TOZIHAT TAB 2</p>
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">MAHDOODE MAKANI</label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Family Home">SUB</option>
                                        <option value="Apartment">SUB</option>
                                        <option value="Condo">SUB</option>
                                        <option value="Villa">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">METRAJ</label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMinDropDown">Min Price</label><br/>
                                    <select name="priceMinDropdown" id="priceMinDropDown" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="$100,000">$100,000</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$800,000">$800,000</option>
                                        <option value="$900,000">$900,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMaxDropdown">Max Price</label><br/>
                                    <select name="priceMaxDropdown" id="priceMaxDropdown" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$700,000">$700,000</option>
                                        <option value="$900,000">$900,000</option>
                                        <option value="$1,000,000">$1,000,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">MELK</label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">SUB</option>
                                        <option value="2">SUB</option>
                                        <option value="3">SUB</option>
                                        <option value="4">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">ANBAR</label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">Area</label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="FIND PROPERTIES" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB 2 -->
                <div class="filterContent" id="tab3">
                    <p>TOZIHAT TAB 3</p>
                    <form method="post" action="#">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="propertyType">MAHDOODE MAKANI</label><br/>
                                    <select name="property type" id="propertyType" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Family Home">SUB</option>
                                        <option value="Apartment">SUB</option>
                                        <option value="Condo">SUB</option>
                                        <option value="Villa">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-6">
                                <div class="formBlock">
                                    <label for="location">METRAJ</label><br/>
                                    <select name="location" id="location" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMinDropDown">Min Price</label><br/>
                                    <select name="priceMinDropdown" id="priceMinDropDown" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="$100,000">$100,000</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$800,000">$800,000</option>
                                        <option value="$900,000">$900,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-3">
                                <div class="formBlock">
                                    <label for="priceMaxDropdown">Max Price</label><br/>
                                    <select name="priceMaxDropdown" id="priceMaxDropdown" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="$200,000">$200,000</option>
                                        <option value="$300,000">$300,000</option>
                                        <option value="$400,000">$400,000</option>
                                        <option value="$500,000">$500,000</option>
                                        <option value="$600,000">$600,000</option>
                                        <option value="$700,000">$700,000</option>
                                        <option value="$900,000">$900,000</option>
                                        <option value="$1,000,000">$1,000,000</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6" style="float: right;">
                                <div class="formBlock">
                                    <label for="beds">MELK</label><br/>
                                    <select name="beds" id="beds" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">SUB</option>
                                        <option value="2">SUB</option>
                                        <option value="3">SUB</option>
                                        <option value="4">SUB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="baths">ANBAR</label><br/>
                                    <select name="baths" id="baths" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <label for="area">Area</label><br/>
                                    <select name="area" id="area" class="formDropdown">
                                        <option value="">Any</option>
                                        <option value="Option 1">Option 1</option>
                                        <option value="Option 2">Option 2</option>
                                        <option value="Option 3">Option 3</option>
                                        <option value="Option 4">Option 4</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6">
                                <div class="formBlock">
                                    <input class="buttonColor" type="submit" value="FIND PROPERTIES" style="margin-top:24px;">
                                </div>
                            </div>
                            <div style="clear:both;"></div>
                        </div>
                    </form>
                </div><!-- END TAB 3 -->
            </div><!-- END CONTAINER -->
        </section>
        <!-- end horizontal filter -->

        <!-- start recent properties -->
        <section class="properties">
            <div class="container">
                        <div class="container">
                            @yield('content')
                        </div>


                <h3>RECENTLY ADDED</h3>
                <div class="divider"></div>
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">ANBAR</a>
                                <a href="#" class="propertyImgLink">
                                    {{ HTML::image('frontend/images/home1.jpg', ' ', array('class' => 'propertyImg')) }}
                                </a>
                                <h4><a href="#">ADDRESS</a></h4>
                                <p>OWNER</p>
                                <div class="divider thin"></div>
                                <p class="forSale">FOR SALE</p>
                                <p class="price">$687,000</p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td>
                                        {{ HTML::image('frontend/images/icon-area.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        2,412m
                                    </td>


                                    <td>
                                        {{ HTML::image('frontend/images/icon-bed.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        OPTION
                                    </td>
                                    <td>
                                        {{ HTML::image('frontend/images/icon-drop.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        OPTION</td>
                                </tr>
                            </table> 
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">ANBAR</a>
                                <a href="#" class="propertyImgLink">
                                    {{ HTML::image('frontend/images/home1.jpg', ' ', array('class' => 'propertyImg')) }}
                                </a>
                                <h4><a href="#">ADDRESS</a></h4>
                                <p>OWNER</p>
                                <div class="divider thin"></div>
                                <p class="forSale">FOR SALE</p>
                                <p class="price">$687,000</p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td>
                                         {{ HTML::image('frontend/images/icon-area.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        2,412m
                                    </td>

                                    <td>
                                         {{ HTML::image('frontend/images/icon-bed.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        OPTION
                                    </td>
                                    <td>
                                         {{ HTML::image('frontend/images/icon-drop.png', ' ', array('style' => 'margin-right:7px;')) }}
                                        OPTION
                                    </td>
                                </tr>
                            </table> 
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">ANBAR</a>
                                <a href="#" class="propertyImgLink">
                                    {{ HTML::image('frontend/images/home1.jpg', ' ', array('class' => 'propertyImg')) }}
                                </a>
                                <h4><a href="#">ADDRESS</a></h4>
                                <p>OWNER</p>
                                <div class="divider thin"></div>
                                <p class="forSale">FOR SALE</p>
                                <p class="price">$687,000</p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td> {{ HTML::image('frontend/images/icon-area.png', ' ', array('style' => 'margin-right:7px;')) }}2,412m</td>
                                    <td> {{ HTML::image('frontend/images/icon-bed.png', ' ', array('style' => 'margin-right:7px;')) }}OPTION</td>
                                    <td> {{ HTML::image('frontend/images/icon-drop.png', ' ', array('style' => 'margin-right:7px;')) }}OPTION</td>
                                </tr>
                            </table> 
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <div class="propertyItem">
                            <div class="propertyContent">
                                <a class="propertyType" href="#">ANBAR</a>
                                <a href="#" class="propertyImgLink">
                                    {{ HTML::image('frontend/images/home1.jpg', ' ', array('class' => 'propertyImg')) }}
                                </a>
                                <h4><a href="#">ADDRESS</a></h4>
                                <p>OWNER</p>
                                <div class="divider thin"></div>
                                <p class="forSale">FOR SALE</p>
                                <p class="price">$687,000</p>
                            </div>
                            <table border="1" class="propertyDetails">
                                <tr>
                                    <td> {{ HTML::image('frontend/images/icon-area.png', ' ', array('style' => 'margin-right:7px;')) }}2,412m</td>
                                    <td> {{ HTML::image('frontend/images/icon-bed.png', ' ', array('style' => 'margin-right:7px;')) }}OPTION</td>
                                    <td> {{ HTML::image('frontend/images/icon-drop.png', ' ', array('style' => 'margin-right:7px;')) }}OPTION</td>
                                </tr>
                            </table> 
                        </div>
                    </div>
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
        <!-- end recent properties -->

        <!-- start services section -->
        <section class="services">
            <div class="container">
                <h1>SLIDERS ADDS COMES HERE</h1><br/><br/>

            </div><!-- end container -->
        </section>
        <!-- end services section -->

        <!-- start  section -->
        <section class="Lux">
            <div class="container">
                <h1>PLACE FOR <span>LUX</span></h1><br/><br/>
            </div>
        </section>
        <!-- end  section -->

        <!-- start call to action -->
        <section class="callToAction" style="margin-top: 50px">
            <div class="container">
                <div class="ctaBox">
                    <div class="col-lg-9">
                        <h1>Get started today <span>CONTACT</span> us!</h1>
                        <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Quisque eget ante vel nunc lorem ipsum rhoncus.</p>
                    </div>
                    <div class="col-lg-3">
                        <a style="float:right; margin-top:15px;" class="buttonColor" href="#">CONTACT US</a>
                    </div>
                    <div style="clear:both;"></div>
                </div>
            </div>
        </section>
        <!-- end call to action -->

        <footer id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <h4><a class="footerLogo" href="#">ANBAR <span>YAB</span></a></h4>
                        <p>Lorem ipsum dolor amet, consectetur adipiscing elit. Sed ut 
                            purus eget nunc ut dignissim cursus at a nisl. Mauris vitae 
                            turpis quis eros egestas tempor sit amet a arcu. Duis egestas 
                            hendrerit diam.</p>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6">
                        <h4>CONTACT</h4>
                        <ul class="contactList">
                            <li>
                                 {{ HTML::image('frontend/images/icon-pin.png', ' ', array('class' => 'icon')) }}
                             ADDRESS</li>
                            <li>{{ HTML::image('frontend/images/icon-phone.png', ' ', array('class' => 'icon')) }}
                             ADDRESS</li> NUMBER</li>
                            <li>{{ HTML::image('frontend/images/icon-mail.png', ' ', array('class' => 'icon')) }}
                             ADDRESS</li> hello@something.com</li>
                        </ul>
                    </div>


                </div><!-- end row -->
            </div><!-- end footer container -->
        </footer>

        <div class="bottomBar">
            <div class="container">
                <p>ANBAR YAB COPYRIGHT 2014</p>
                <ul class="socialIcons">
                    <li><a href="#">
                        {{ HTML::image('frontend/images/icon-fb.png', ' ') }}
                    </a></li>

                    <li><a href="#">
                        {{ HTML::image('frontend/images/icon-twitter.png', ' ') }}
                      </a></li>

                    <li><a href="#">
                        {{ HTML::image('frontend/images/icon-google.png', ' ') }}
                    </a></li>

                    <li><a href="#">
                        {{ HTML::image('frontend/images/icon-rss.png', ' ') }}
                    </a></li>
                </ul>
            </div>
        </div>

        {{ HTML::script('frontend/js/jquery.js')}}
        {{ HTML::script('frontend/js/bootstrap.min.js')}}
        {{ HTML::script('frontend/js/respond.js')}}
        {{ HTML::script('frontend/js/tabs.js')}}
        {{ HTML::script('frontend/js/jquery.nouislider.min.js') }}

        <script>
            //Setup price slider 
            var Link = $.noUiSlider.Link;

            $(".priceSlider").noUiSlider({
                range: {
                    'min': 0,
                    'max': 800000
                }
                ,start: [150000, 550000]
                ,step: 1000
                ,margin: 100000
                ,connect: true
                ,direction: 'ltr'
                ,orientation: 'horizontal'
                ,behaviour: 'tap-drag'
                ,serialization: {
                    lower: [
                        new Link({
                            target: $("#price-min")
                        })
                    ],

                    upper: [
                        new Link({
                            target: $("#price-max")
                        })
                    ],

                    format: {
                        // Set formatting
                        decimals: 0,
                        thousand: ',',
                        prefix: '$'
                    }
                }
            });
        </script>

    </body>

</html>
