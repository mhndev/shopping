
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>پنل مدیریت سایت</title>

    <!-- Bootstrap core CSS -->


    {{ HTML::style('css/bootstrap.css') }}
    {{ HTML::style('css/sb-admin.css') }}
    {{ HTML::style('font-awesome/css/font-awesome.min.css') }}
    {{ HTML::style('css/morris-0.4.3.min.css') }}

  </head>

  <body>

    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">منوهای خودکار</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.html">قالب مدیریت سایت</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li class="active"><a href="index.html"><i class="fa fa-dashboard"></i> پیشخوان</a></li>
            <li><a href="charts.html"><i class="fa fa-bar-chart-o"></i> نمودارها</a></li>
            <li><a href="tables.html"><i class="fa fa-table"></i> جدول ها</a></li>
            <li><a href="forms.html"><i class="fa fa-edit"></i> فرم ها</a></li>
            <li><a href="typography.html"><i class="fa fa-font"></i> نحوه چاپ</a></li>
            <li><a href="bootstrap-elements.html"><i class="fa fa-desktop"></i> عناصر بوت استرپ</a></li>
            <li><a href="bootstrap-grid.html"><i class="fa fa-wrench"></i> چینش بوت استرپ</a></li>
            <li><a href="blank-page.html"><i class="fa fa-file"></i> صفحه خالی</a></li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-caret-square-o-down"></i> منوی کشویی <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">منوی اول</a></li>
                <li><a href="#">منوی دوم</a></li>
                <li><a href="#">منوی سوم</a></li>
                <li><a href="#">منوی چهارم</a></li>
              </ul>
            </li>
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">
            <li class="dropdown messages-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> پیغام ها <span class="badge">7</span> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li class="dropdown-header"><span>7</span> پیغام های جدید</li>
                <li class="message-preview">
                  <a href="#">
                    <span class="avatar">
                      {{ HTML::image('http://placehold.it/50x50') }}
                    </span>
                    <span class="name">حسین شوشتری:</span>
                    <span class="message">سلام من منتظر پیغام شما هستم...</span>
                    <span class="time"><i class="fa fa-clock-o"></i> 4:34 بعد از ظهر</span>
                  </a>
                </li>
                <li class="divider"></li>
                <li class="message-preview">
                  <a href="#">
                    <span class="avatar">
                      {{ HTML::image('http://placehold.it/50x50') }}
                    </span>
                    <span class="name">رضا صفری:</span>
                    <span class="message">سلام با تشکر از سایت خوبتون و با تقدیر از...</span>
                    <span class="time"><i class="fa fa-clock-o"></i> 4:34 قبل از ظهر</span>
                  </a>
                </li>
                <li class="divider"></li>
                <li class="message-preview">
                  <a href="#">
                    <span class="avatar">
                      {{ HTML::image('http://placehold.it/50x50') }}
                    </span>
                    <span class="name">محمد جواد رضایی:</span>
                    <span class="message">با تشکر از شما می خواستم بدونم هزینه سایت ...</span>
                    <span class="time"><i class="fa fa-clock-o"></i> 4:34 قبل از ظهر</span>
                  </a>
                </li>
                <li class="divider"></li>
                <li><a href="#">نمایش صندوق دریافتی <span class="badge">7</span></a></li>
              </ul>
            </li>
            <li class="dropdown alerts-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> اطلاعیه ها <span class="badge">3</span> <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">معمولی <span class="label label-default">معمولی</span></a></li>
                <li><a href="#">اصلی <span class="label label-primary">اصلی</span></a></li>
                <li><a href="#">موفقیت <span class="label label-success">موفقیت</span></a></li>
                <li><a href="#">اطلاعات <span class="label label-info">اطلاعات</span></a></li>
                <li><a href="#">اخطار <span class="label label-warning">اخطار</span></a></li>
                <li><a href="#">خطر <span class="label label-danger">خطر</span></a></li>
                <li class="divider"></li>
                <li><a href="#">نمایش همه</a></li>
              </ul>
            </li>
            <li class="dropdown user-dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> مسیح ایرانی <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#"><i class="fa fa-user"></i> پروفایل</a></li>
                <li><a href="#"><i class="fa fa-envelope"></i> صندوق پیام <span class="badge">7</span></a></li>
                <li><a href="#"><i class="fa fa-gear"></i> تنظیمات</a></li>
                <li class="divider"></li>
                <li><a href="#"><i class="fa fa-power-off"></i> خارج شدن</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>پیشخوان <small>نمایش فعل و انفعالات</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> پیشخوان</li>
            </ol>
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              به صفحه مدیریت سایت خود  خوش آمدید <a class="alert-link" href="http://w3template.ir">شرکت W3</a> پشتیبان شما در تمامی زمینه های طراحی و پیاده سازی سایت است. شما می توانید قالب های سایت را از سایت ما دریافت کنید سفارش قالب بدهید فارسی سازی قالب خود را به ما واگذار کنید و... با ما همراه باشید
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-3">
            <div class="panel panel-info">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-comments fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading">12</p>
                    <p class="announcement-text">دیدگاه</p>
                  </div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
          جدول دیدگاه 
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-warning">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-check fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading">12</p>
                    <p class="announcement-text">عملیات</p>
                  </div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      عملیات
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-danger">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-tasks fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading">18</p>
                    <p class="announcement-text">بازدید جدید</p>
                  </div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      بازدید جدید
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="panel panel-success">
              <div class="panel-heading">
                <div class="row">
                  <div class="col-xs-6">
                    <i class="fa fa-comments fa-5x"></i>
                  </div>
                  <div class="col-xs-6 text-right">
                    <p class="announcement-heading">4</p>
                    <p class="announcement-text">سفارش کار</p>
                  </div>
                </div>
              </div>
              <a href="#">
                <div class="panel-footer announcement-bottom">
                  <div class="row">
                    <div class="col-xs-6">
                      سفارش کار
                    </div>
                    <div class="col-xs-6 text-right">
                      <i class="fa fa-arrow-circle-right"></i>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> نمودار ترافیک سایت</h3>
              </div>
              <div class="flot-chart">
                  <div class="flot-chart-content" id="flot-chart-line"></div>
                </div>
            </div>
          </div>
        </div><!-- /.row -->

        <div class="row">
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-long-arrow-right"></i> منابع ورودی به سایت</h3>
              </div>
              <div class="panel-body">
                <div id="morris-chart-donut"></div>
                <div class="text-right">
                  <a href="#">نمایش جزئیات <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-clock-o"></i> آخرین رویدادها</h3>
              </div>
              <div class="panel-body">
                <div class="list-group">
                  <a href="#" class="list-group-item">
                    <span class="badge">همین الان</span>
                    <i class="fa fa-calendar"></i> بروزرسانی سایت
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">4 دقیقه قبل</span>
                    <i class="fa fa-comment"></i> دیدگاه در پست
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">23 دقیقه قبل</span>
                    <i class="fa fa-truck"></i> درخواست
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">46 دقیق قبل</span>
                    <i class="fa fa-money"></i> درخواست کار
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">1ساعت قبل</span>
                    <i class="fa fa-user"></i> طراحی سایت
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">2ساعت قبل</span>
                    <i class="fa fa-check"></i> اطلاعت تماس
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">دیروز</span>
                    <i class="fa fa-globe"></i> درخواست عکس
                  </a>
                  <a href="#" class="list-group-item">
                    <span class="badge">دوروز پیش</span>
                    <i class="fa fa-check"></i> ارسال دیدگاه
                  </a>
                </div>
                <div class="text-right">
                  <a href="#">نمایش همه رویداد ها <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-money"></i> آخرین تراکنش ها</h3>
              </div>
              <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-bordered table-hover table-striped tablesorter">
                    <thead>
                      <tr>
                        <th>سفارش # <i class="fa fa-sort"></i></th>
                        <th>تاریخ سفارش <i class="fa fa-sort"></i></th>
                        <th>زمان سفارش <i class="fa fa-sort"></i></th>
                        <th>واحد پرداخت (ریال) <i class="fa fa-sort"></i></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>3326</td>
                        <td>1392/02/13</td>
                        <td>3:29 </td>
                        <td>ریال321.33</td>
                      </tr>
                      <tr>
                        <td>3325</td>
                        <td>1392/02/13</td>
                        <td>3:20 </td>
                        <td>ریال234.34</td>
                      </tr>
                      <tr>
                        <td>3324</td>
                        <td>1392/02/13</td>
                        <td>3:03 </td>
                        <td>ریال724.17</td>
                      </tr>
                      <tr>
                        <td>3323</td>
                        <td>1392/02/13</td>
                        <td>3:00 </td>
                        <td>ریال23.71</td>
                      </tr>
                      <tr>
                        <td>3322</td>
                        <td>1392/02/13</td>
                        <td>2:49 </td>
                        <td>ریال8345.23</td>
                      </tr>
                      <tr>
                        <td>3321</td>
                        <td>1392/02/13</td>
                        <td>2:23 </td>
                        <td>ریال245.12</td>
                      </tr>
                      <tr>
                        <td>3320</td>
                        <td>1392/02/13</td>
                        <td>2:15 </td>
                        <td>ریال5663.54</td>
                      </tr>
                      <tr>
                        <td>3319</td>
                        <td>1392/02/13</td>
                        <td>2:13 </td>
                        <td>ریال943.45</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="text-right">
                  <a href="#">نمایش همه تراکنش ها <i class="fa fa-arrow-circle-right"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div><!-- /.row -->

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->


<!-- JavaScript -->
    {{ HTML::script('js/jquery-1.10.2.js') }}
    {{ HTML::script('js/bootstrap.js') }}


<!-- Page Specific Plugins -->
    {{ HTML::script('js/raphael-min.js') }}
    {{ HTML::script('js/morris-0.4.3.min.js') }}
    {{ HTML::script('js/chart-data-morris.js') }}
    {{ HTML::script('js/tablesorter/jquery.tablesorter.js') }}
    {{ HTML::script('js/tablesorter/tables.js') }}

  </body>
</html>
