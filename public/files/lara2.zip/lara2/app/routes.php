<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/



Route::get('/', function()
{
	return View::make('hello');
});



Route::resource('new','NewController');
Route::resource('index','IndexController');
Route::resource('admin','AdminController');
Route::get('search', 'HomeController@search');
Route::get('search2', 'HomeController@search2');
Route::get('search3', 'HomeController@search3');
Route::get('search4', 'HomeController@search4');
Route::get('search5', 'HomeController@search5');

Route::get('getform', 'HomeController@getform');